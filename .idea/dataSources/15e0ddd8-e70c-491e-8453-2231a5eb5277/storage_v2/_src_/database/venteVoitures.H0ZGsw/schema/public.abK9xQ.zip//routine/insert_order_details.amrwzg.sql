create function insert_order_details() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO OrderDetails (orderID, carID, quantite_commandee, prix_unitaire)
    VALUES (NEW.orderID, NEW.carID, NEW.quantite_commandee, (SELECT prix_unitaire FROM Cars WHERE carID = NEW.carID));
    RETURN NEW;
END;
$$;

alter function insert_order_details() owner to postgres;

