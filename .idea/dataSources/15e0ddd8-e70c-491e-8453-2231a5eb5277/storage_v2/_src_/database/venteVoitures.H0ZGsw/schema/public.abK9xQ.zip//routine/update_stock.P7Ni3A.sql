create function update_stock() returns trigger
    language plpgsql
as
$$
    DECLARE qnt INTEGER;
BEGIN
    SELECT quantite_commandee INTO qnt FROM orderdetails WHERE carid = NEW.carID;
    UPDATE cars
    SET quantite_en_stock = quantite_en_stock - qnt
    WHERE carid = NEW.carid;
    RETURN NEW;
END;
$$;

alter function update_stock() owner to postgres;

