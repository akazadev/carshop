create function update_stock_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Mise à jour du stock dans la table "Cars" après l'insertion dans la table "orderdetails"
    UPDATE Cars
    SET quantite_en_stock = quantite_en_stock - NEW.quantite_commandee
    WHERE carID = NEW.carID;

    RETURN NEW;
END;
$$;

alter function update_stock_trigger() owner to postgres;

